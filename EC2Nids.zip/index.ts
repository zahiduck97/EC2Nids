import 'dotenv/config';
import Server from "./src/model/server";

const server = new Server();

server.listen();
